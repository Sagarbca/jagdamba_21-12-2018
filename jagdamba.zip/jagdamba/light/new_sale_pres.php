<?php
error_reporting(1);
session_start();
//if($name = $_SESSION['name']) 
if ($_SESSION['name']=="") {
header('location:index.php');
}
$name=$_SESSION['name'];
?>

<?php
session_start();
$name = $_SESSION['name']; 
?>
<?php
include("config.php");
if (isset($_POST['csubmit'])) {
	$client = $_POST['client'];
$mobile_no = $_POST['mob'];
$address = $_POST['address'];
	$query1 = "INSERT INTO `client_press`(`name`, `mobile_no`, `address`)  VALUES ('$client','$mobile_no','$address')";
// echo $query;
$insert1 = $mysqli->query($query1);
echo "<script>window.open('new_sale_pres1.php','_self')</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<!-- BEGIN HEAD -->

<!-- Mirrored from radixtouch.in/templates/admin/redstar/source/light/schedule.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 26 Jun 2018 06:08:39 GMT -->
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="width=device-width, initial-scale=1" name="viewport" />
<meta name="description" content="Responsive Admin Template" />
<meta name="author" content="RedstarHospital" />
<title>JAGDAMBA PRINT LINE</title>
<!-- google font -->
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&amp;subset=all" rel="stylesheet" type="text/css" />
<!-- icons -->
<link href="../assets/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<!--bootstrap -->

<link href="../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<!-- Material Design Lite CSS -->
<link rel="stylesheet" href="../assets/material/material.min.css">
<link rel="stylesheet" href="css/material_style.css">
<!-- Theme Styles -->
<link href="css/theme_style.css" rel="stylesheet" id="rt_style_components" type="text/css" />
<link href="css/plugins.min.css" rel="stylesheet" type="text/css" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" />
<link href="css/theme-color.css" rel="stylesheet" type="text/css" />
<!-- favicon -->
<link rel="shortcut icon" href="img/favicon.ico" />
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css"> 
</head>
<!-- END HEAD -->
<body class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-white white-sidebar-color logo-indigo">
<div class="page-wrapper">
<!-- start header -->
<div class="page-header navbar navbar-fixed-top">
<div class="page-header-inner ">
<!-- logo start -->
<div class="page-logo" style="padding: 0px 0px 0px 0px; background:white;">
<a href="dashboard_pres.php">
<img src="logo.jpg" style="width:70%; height:60px; margin-left:25px;"> </a>
</div>
<!-- logo end -->
<ul class="nav navbar-nav navbar-left in">
<li><a href="#" class="menu-toggler sidebar-toggler"><i class="icon-menu"></i></a></li>
</ul>

<!-- start mobile menu -->
<a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse">
<span></span>
</a>
<!-- end mobile menu -->
<!-- start header menu -->
<div class="top-menu">
<ul class="nav navbar-nav pull-right">
<!-- start language menu -->

<!-- end language menu -->
<!-- start notification dropdown -->

<!-- end notification dropdown -->
<!-- start message dropdown -->

<!-- start manage user dropdown -->
<li class="dropdown dropdown-user">
<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
<?php 

$sqll = "SELECT photo  from profile_pic";
$queryl = $dbh -> prepare($sqll);
$queryl->execute();
$resultss=$queryl->fetchAll(PDO::FETCH_OBJ);
$cntt=1;
if($queryl->rowCount() > 0)
{
foreach($resultss as $rows) 
{ ?>
<img alt="" class="img-circle " src="<?php echo $rows->photo;?>" />
<span class="username username-hide-on-mobile"> <?php echo $name; ?> </span>
<i class="fa fa-angle-down"></i>
</a>
<ul class="dropdown-menu dropdown-menu-default">



<li class="divider"> </li>

<li>
<a href="logout.php">
<i class="icon-logout"></i> Log Out </a>
</li>
<li>
<a href="changepassword.php">
<i class="icon-lock"></i> Change Password </a>
</li>
</ul>
</li>
<!-- end manage user dropdown -->

</ul>
</div>
</div>
</div>
<!-- end header -->

<!-- start page container -->
<div class="page-container">
<!-- start sidebar menu -->
<div class="sidebar-container">
<div class="sidemenu-container navbar-collapse collapse fixed-menu">
<div id="remove-scroll" class="left-sidemenu">
<ul class="sidemenu  page-header-fixed slimscroll-style" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
<li class="sidebar-toggler-wrapper hide">
<div class="sidebar-toggler">
<span></span>
</div>
</li>
<li class="sidebar-user-panel">
<div class="user-panel">
<div class="pull-left image">
<img src="<?php echo $rows->photo;?>" class="img-circle user-img-circle" alt="User Image" />
</div>
<div class="pull-left info">
<p> <?php echo $name; ?></p>
<a href="#"><i class="fa fa-circle user-online"></i><span class="txtOnline"> Online</span></a>
</div>
</div>
<?php } }
?>
</li>
<li class="nav-item start active open">
<a href="dashboard_pres.php" class="nav-link nav-toggle">
<i class="material-icons">dashboard</i>
<span class="title">Dashboard</span>
<span class="selected"></span>

</a>

</li>

<!--<li class="nav-item  ">
<a href="#" class="nav-link nav-toggle"><i class="material-icons">assignment</i>
<span class="title">Vendors</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item  ">
<a href="add_vendor.php" class="nav-link "> <span class="title"> Add Vendor</span>
</a>
</li>
<li class="nav-item  ">
<a href="view_vendor.php" class="nav-link "> <span class="title"> All Vendor</span>
</a>
</li>
<li class="nav-item  ">
<a href="view_vendor_product.php" class="nav-link "> <span class="title"> All Vendor Products</span>
</a>
</li>


</ul>
</li>
-->
<!--<li class="nav-item  ">
<a href="#" class="nav-link nav-toggle"><i class="material-icons">assignment</i>
<span class="title">Clients</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item  ">
<a href="add_client.php" class="nav-link "> <span class="title"> Add Clients</span>
</a>
</li>
<li class="nav-item  ">
<a href="view_client.php" class="nav-link "> <span class="title"> View Clients</span>
</a>
</li>
<li class="nav-item  ">
<a href="view_client_product.php" class="nav-link "> <span class="title"> All Clients Products</span>
</a>
</li>

</ul>
</li>-->

<!--<li class="nav-item  ">
<a href="#" class="nav-link nav-toggle"><i class="material-icons">assignment</i>
<span class="title">Staff</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item">
<a href="add_staff.php" class="nav-link"> <span class="title"> Add Staff</span>
</a>
</li>
<li class="nav-item">
<a href="all_staff.php" class="nav-link"> <span class="title"> All Staff</span>
</a>
</li>


</ul>
</li>-->

<!--<li class="nav-item">
<a href="#" class="nav-link nav-toggle"><i class="material-icons">assignment</i>
<span class="title">Expenses</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item">
<a href="add_expenses.php" class="nav-link "> <span class="title"> Add expenses</span>
</a>
</li>
<li class="nav-item">
<a href="all_expenses.php" class="nav-link"> <span class="title"> All expenses</span>
</a>
</li>


</ul>
</li>-->

<li class="nav-item  ">
<a href="#" class="nav-link nav-toggle"><i class="material-icons">assignment</i>
<span class="title">Sale</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item  ">
<a href="new_sale_pres.php" class="nav-link "> <span class="title"> New Sale</span>
</a>
</li>
<li class="nav-item  ">
<a href="sale_list_pres.php" class="nav-link "> <span class="title">Sale List</span>
</a>
</li>
</ul>
</li>
<li class="nav-item  ">
<a href="#" class="nav-link nav-toggle"><i class="material-icons">assignment</i>
<span class="title">Client</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item  ">
<a href="add_client_pres.php" class="nav-link "> <span class="title"> Add Client</span>
</a>
</li>
<li class="nav-item  ">
<a href="view_client_pres.php" class="nav-link "> <span class="title">Client List</span>
</a>
</li>
</ul>
</li>




</ul>
</li>


</ul>
</div>
</div>
</div>
<!-- end sidebar menu --> 
<!-- start page content -->
<div class="page-content-wrapper">
<div class="page-content">
<div class="page-bar">
<div class="page-title-breadcrumb">
<div class=" pull-left">
<div class="page-title" style="text-align:center;">New Sale</div>
</div>
<ol class="breadcrumb page-breadcrumb pull-right">
<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="dashboard_pres.php">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
</li>
<li><a class="parent-item" href="dashboard_pres.php">Prescart </a>&nbsp;<i class="fa fa-angle-right"></i>
</li>
<li class="active">New Sale</li>
</ol>
</div>
</div>


<div class="row">
<div class="col-md-12">
<div class="col-md-12">
<div class="tabbable-line">


<div class="tab-content">
<div class="tab-pane active fontawesome-demo" id="tab1">
<div class="row">
<div class="col-md-12">
<div class="card card-topline-red">
<div class="card-head">
<header></header>
<div class="tools">
<a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
<a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
<a class="t-close btn-color fa fa-times" href="javascript:;"></a>
</div>
<button type="button"
	class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect btn-circle btn-primary m-r-20 pull-right"
	data-toggle="modal" data-target="#smallModel">New customer</button>
</div>
<form action="new_sale_pres_config1.php" method="post">
<div class="card-body ">
<div class="row">
<div class="col-md-6 col-sm-6 col-xs-6">
<div class="row" style="width: 1016px;">

<div class="form-group row">
<label class="control-label col-md-3">Client Name:

<span class="required"> * </span>
</label>
<div class="col-md-5">
<input type="text" name="client_name" id="skill_input" placeholder="enter Client Name"  class="form-control input-height" style="width: 494px;"/> </div>
</div>

</div>

<div class="row">
<div class="col-md-6 col-sm-6 col-xs-6">
<div class="row" style="width: 1016px;">
  
<div class="form-group row">
<label class="control-label col-md-3">Date:
<span class="required">  </span>
</label>
<div class="col-md-5">
<input type="text" name="date"  placeholder="dd-mm-YY"  class="form-control input-height" style="width: 494px;"/> </div>
</div>

</div>
</div>

</div>
</div>

</div>
</div>
<div class="table-scrollable">
<table class="table table-hover table-checkable order-column full-width" id="example4">

<tbody>
<thead >
<tr >

<th class="center">No Of Job</th>
<th class="center">Job Name</th>
<th class="center">Quantity of Paper</th>
<th class="center">GSM</th>
<th class="center">Rate</th>
<th class="center">Amount</th>

<th></th>
</tr>
</thead>
<tr >
<td><input type="text" name="quantity[]"  class="next quantity form-control  "   required></td>
<td><input type="text" name="product_name[]" class="next product_name form-control  " ></td>
<td><input type="text" name="quantity_of_paper[]" class="next quant form-control  " ></td>
<td><input type="text" name="per[]"  class="next per form-control " style="width: 83px;" ></td>
<td><input type="text" name="rate[]"  class="next rate allow_only_num form-control " style="width: 83px;"> </td>
<td><input type="text" name="amount[]" class="next amount form-control " style="width: 83px;" readonly ></td> 

<td><input type="hidden" name="gst[]" class="next gst allow_only_num form-control"  ></td>
<td><input type="hidden" name="igst[]" class="next igst allow_only_num form-control" ></td>
<td><input type="hidden" name="total_amount[]" class="next last total_amount form-control"  value="0" readonly size="1"></td> 
<td><input type="button" name="addRow " class="add col-md-12" value='+'  ></td>
<td><input type="button" name="removeRow" class="removeRow col-md-12" value='-'></td>
<td class="hide"><input type="hidden" name="gst_amount[]" class="next gst_amount" ></td>
<td class="hide"><input type="hidden" name="cgst[]" class="next cgst"></td>
<td class="hide"><input type="hidden" name="cgst_amount[]" class="next cgst_amount"></td>
<td class="hide"><input type="hidden" name="sgst[]" class="next sgst"></td>
<td class="hide"><input type="hidden" name="sgst_amount[]" class="next sgst_amount"></td>
<td class="hide"><input type="hidden" name="igst_amount[]" class="next igst_amount"></td>
</tbody>
</table>
</div>
<br>
<br>
<br>
<br>
<br>
<div class="form-group row">
<label class="control-label col-md-3">Total(₹) :
<span class="required"> * </span>
</label>
<div class="col-md-5">
<input type="text" name="totalPrice" id="totalPrice" class="totalPrice form-control input-height" readonly> </div>
</div>
<div class="form-group row">
<label class="control-label col-md-3">Paid Amount(₹) :
<span class="required"> * </span>
</label>
<div class="col-md-5">
<input type="text" name="paid_amount" id="paid" class="totalPrice form-control input-height" required> </div>
</div>
<div class="form-group row">
<label class="control-label col-md-3">Dues Amount(₹) :
<span class="required"> * </span>
</label>
<div class="col-md-5">
<input type="text" name="dues_amount" id="dues" class="totalPrice form-control input-height" readonly > </div>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
 
<div class="form-actions">
<div class="row">
<div class="offset-md-3 col-md-9">
<button type="submit" name="submit" class="btn btn-info" id="btnGeachrow">Submit</button>
<a href="sale_list_pres.php" class="btn btn-danger">Cancel</a>

</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- end page content -->
<!-- start chat sidebar -->
<!-- Small Model -->
<div class="modal fade" id="smallModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="exampleModalLabel">Add Client</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            	<div class="card-body " id="bar-parent1">
                <form class="form-horizontal" action="" method="post">
                    <div class="form-group row">
                        <label for="horizontalFormEmail" class="col-sm-2 control-label">Client Name</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="horizontalFormEmail" name="client" placeholder="Client Name">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="horizontalFormEmail" class="col-sm-2 control-label">Mobile No</label>
                        <div class="col-sm-10">
                            <input type="text" name="mob" class="form-control" id="horizontalFormEmail" placeholder="Mobile No">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="horizontalFormEmail" class="col-sm-2 control-label">Address</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="horizontalFormEmail" name="address" placeholder="Address">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="offset-md-3 col-md-9">
                            <button type="submit" name="csubmit" class="btn btn-info m-r-20">Submit</button>
                            
                        </div>
                    </div>
                </form>
            </div>
                <!--form-->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                
            </div>
        </div>
    </div>
</div>
<!-- start footer -->
<div class="page-footer">
<div class="page-footer-inner"> 2018 &copy; Jagdamba Management By
<a href="https://www.succexa.in" target="_top" class="makerCss">succexa</a>
</div>
<div class="scroll-to-top">
<i class="icon-arrow-up"></i>
</div>
</div>
<!-- end footer -->
</div>
<!-- start js include path -->
<script src="../assets/jquery.min.js" ></script>
<script src="../assets/popper/popper.js" ></script>
<script src="../assets/jquery.blockui.min.js" ></script>
<script src="../assets/jquery.slimscroll.js"></script>
<!-- bootstrap -->
<script src="../assets/bootstrap/js/bootstrap.min.js" ></script>
<script src="../assets/bootstrap-switch/js/bootstrap-switch.min.js" ></script>
<!-- data tables -->
<script src="../assets/datatables/jquery.dataTables.min.js" ></script>
<script src="../assets/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js" ></script>
<script src="../assets/table_data.js" ></script>
<!-- Common js-->
<script src="../assets/app.js" ></script>
<script src="../assets/layout.js" ></script>
<script src="../assets/theme-color.js" ></script>
<!-- Material -->
<script src="../assets/material/material.min.js"></script>
<!-- end js include path -->
</body>

<!-- Mirrored from radixtouch.in/templates/admin/redstar/source/light/all_doctors.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 26 Jun 2018 06:09:19 GMT -->
</html>

<script
src="https://code.jquery.com/jquery-3.3.1.min.js" >
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script>
$(function() {
    $("#skill_input").autocomplete({
        source: "client_search.php",
    });
});
</script>
<script>
//  $function show_total_amount(){

// }
//$(function(){
$(document).ready(function(){
$(".hide").hide();
var html='<tr><td><input type="text" name="quantity[]" class="next quantity form-control" size="5" required></td><td><input type="text" name="product_name[]" class="next product_name form-control" size="45"></td><td><input type="text" name="quantity_of_paper[]" class="next quant form-control  " ></td><td><input type="text" name="per[]" class="next per form-control" size="4" ></td><td><input type="text" name="rate[]" class="next rate allow_only_num form-control" size="5"> </td><td><input type="text" name="amount[]" class="next amount form-control" readonly size="7"></td> <td><input type="hidden" name="gst[]" class="next gst allow_only_num form-control" size="1" ></td><td><input type="hidden" name="igst[]" class="next igst allow_only_num form-control" size="1"></td><td><input type="hidden" name="total_amount[]" class="next last total_amount form-control"  value="0" readonly size="8"></td> <td><input type="button" name="addRow " class="add col-md-12" value="+"  ></td><td><input type="button" name="removeRow" class="removeRow col-md-12" value="-"></td><td class="hide"><input type="hidden" name="gst_amount[]" class="next gst_amount" ></td><td class="hide"><input type="hidden" name="cgst[]" class="next cgst"></td><td class="hide"><input type="hidden" name="cgst_amount[]" class="next cgst_amount"></td><td class="hide"><input type="hidden" name="sgst[]" class="next sgst"></td><td class="hide"><input type="hidden" name="sgst_amount[]" class="next sgst_amount"></td><td class="hide"><input type="hidden" name="igst_amount[]" class="next igst_amount"></td></tr>'; 
//variables


//add row to form
$(document).on('click','.add',function(e){

$(this).parents('tr').parents("tbody").append(html);;

});



//remove rows form the table 
$(document).on('click','.removeRow',function(e){

if ($('#purchaseItems .add').length > 1) {

$(this).parents('tr').remove();
var total = 0;
var tsum = 0;
var gst_total = 0;
//calculate tsum
$(".amount").each(function() {

tsum = tsum + parseFloat($(this).val());

});
$(".tsum").val(tsum.toFixed(2));
//calculate gst_amount
$(".gst_amount").each(function() {

gst_total = gst_total + parseFloat($(this).val());

});
$(".gst_total").val(gst_total.toFixed(2));

//calcuate total_amount
$(".total_amount").each(function() {

total = total + parseFloat($(this).val());

});
$("#totalPrice").val(total.toFixed(2));

}else{

$('.next').val("");
$("#totalPrice").val('0.00');
$('.net_amount').val('0.00');
$('.dues').val('0.00');
$('.tsum').val('0.00');
$('.gst_amount').val('0.00');

}
});
//populate values form the first row


//on keypress
$(document).on('click', '.add', function() {

// var row = $(this).parents('tr');
//var clone = row.clone();

// clear the values
// var tr = clone.closest('tr');

//tr.find('.next').val('');


//  $(this).closest('tr').after(clone);

var total = 0;

$(".total_amount").each(function() {
if (!$(this).val() == '') {
total = total + parseFloat($(this).val());
}
});

$("#totalPrice").val(total.toFixed(2));
var tsum = 0;
var gst_total = 0;
//calculate tsum
$(".amount").each(function() {
if (!$(this).val() == '') {
tsum = tsum + parseFloat($(this).val());

}
});
$(".tsum").val(tsum.toFixed(2));
//calculate gst_amount
$(".gst_amount").each(function() {
if (!$(this).val() == '') {
gst_total = gst_total + parseFloat($(this).val());

}
});
$(".gst_total").val(gst_total.toFixed(2));
});


$(document).on('keyup', ".next,.discount,.payable", function() {



//Getting elements From table

var $product_name = $(this).parents("tr").find(".product_name");
var $hsn_code = $(this).parents("tr").find(".hsn_code");
var $quantity = $(this).parents("tr").find(".quantity");
var $per = $(this).parents("tr").find(".per");
var $rate = $(this).parents("tr").find(".rate");
var $amount = $(this).parents("tr").find(".amount");
var $gst = $(this).parents("tr").find(".gst");
var $gst_amount = $(this).parents("tr").find(".gst_amount");
var $cgst = $(this).parents("tr").find(".cgst");
var $cgst_amount = $(this).parents("tr").find(".cgst_amount");
var $sgst = $(this).parents("tr").find(".sgst");
var $sgst_amount = $(this).parents("tr").find(".sgst_amount");
var $igst = $(this).parents("tr").find(".igst");
var $igst_amount = $(this).parents("tr").find(".igst_amount");
var $total_amount = $(this).parents("tr").find(".total_amount");




//table 1 row data variable declaration
var quantity = 0;
var rate = 0;
var amount = 0;
var gst = 0;
var gst_amount = 0;
var cgst = 0;
var cgst_amount = 0;
var sgst = 0;
var sgst_amount = 0;
var igst = 0;
var igst_amount = 0;
var total = 0;    

//getting values from out side form
var discount = $(".discount").val();
var net_amount =0;
var payable = $(".payable").val();
var dues = 0;
var payment_mode = $(".payment_mode").val();
var deposite_account = $(".deposite_account").val();
var tsum = 0;
var gst_total = 0;

if ($quantity.val() == '' || $rate.val() == '') {
// console.log("No values found.");

amount = 0;
cgst_amount = 0;
sgst_amount = 0;
igst_amount = 0;
total_amount = 0;
payable = 0;
net_amount = 0;
total = 0;
tsum = 0;
gst_total = 0;
$("#totalPrice").val(total.toFixed(2));
//$(".tsum").val(tsum.toFixed(2));
//$(".gst_amount").val(gst_total.toFixed(2));
} 

else {

//console.log("Converting: ", $quantity.val(), $rate.val());
quantity = parseInt($quantity.val());
rate = parseFloat($rate.val());
//console.log("Values found: ", quantity, rate);

amount = quantity * rate;
gst=$gst.val();
gst_amount = amount*gst/100;
cgst = gst/2;
cgst_amount = gst_amount/2;
sgst = gst/2;
sgst_amount = gst_amount/2;
igst = $igst.val();

if(igst!='undefined'&&igst!=''&&igst!=0){igst_amount = amount*igst/100;}

total_amount = amount+gst_amount+igst_amount;

}

$amount.val(Math.round(amount * 100) / 100);
$gst_amount.val(gst_amount.toFixed(2));
$cgst.val(cgst);
$cgst_amount.val(cgst_amount);
$sgst.val(sgst);
$sgst_amount.val(sgst_amount);
$igst_amount.val(igst_amount);
$total_amount.val(total_amount.toFixed(2));
$sgst_amount.val(sgst_amount);


$(".total_amount").each(function() {

if (!$(this).val() == '') {

total = total + parseFloat($(this).val());

}});
$("#totalPrice").val(total.toFixed(2));

//calculate tsum
$(".amount").each(function() {
if (!$(this).val() == '') {
tsum = tsum + parseFloat($(this).val());

}});
$(".tsum").val(tsum.toFixed(2));

//calculate gst_amount
$(".gst_amount").each(function() {
if (!$(this).val() == '') {
gst_total = gst_total + parseFloat($(this).val());

}});
$(".gst_total").val(gst_total.toFixed(2));

net_amount = total-discount;
dues = net_amount-payable;
$('.net_amount').val(net_amount.toFixed(2));
$('.dues').val(dues.toFixed(2));
//alert();
});

});
</script>
<script>

$(document).on('keyup', "#paid", function() {

var dues = 0;

var invoice_amt = $("#totalPrice").val();

var paid = $("#paid").val();



var dues = invoice_amt - paid;

$('#dues').val(dues);

})



</script>