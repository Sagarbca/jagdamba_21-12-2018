 <?php
error_reporting(1);
session_start();
//if($name = $_SESSION['name']) 
if ($_SESSION['name']=="") {
header('location:index.php');
}
$name=$_SESSION['name'];
?>
<?php
session_start();
$vendor_id = $_GET['editsz'];
?>
<?php
include("config.php");
?>
<?php
include_once 'config2.php';
$whereCondition = " WHERE vi.invoice_no >0";
 $v =$_POST['vendor'];
 $f =$_POST['From'];
 $t =$_POST['to'];
if (isset($_POST['vendor']) && $_POST['vendor'] != '') {
$whereCondition .= " AND vi.vendor_id='".$_POST['vendor']."'";
}
if (isset($_POST['invoice']) && $_POST['invoice'] != '') {
$whereCondition .= " AND invoice_no='".$_POST['invoice']."'";
}
//if (isset($_POST['From']) && $_POST['From'] != '') {
//  $whereCondition .= " AND `date` BETWEEN '".$_POST["From"]."' AND '".$_POST["to"]."'";
//}
if (isset( $_POST['From'],$_POST['to'] )) 
{
    $v =$_POST['vendor'];
if ( $_POST['From'] != '' && $_POST['to'] != '' ) {
$whereCondition .= " AND `invoice_date` BETWEEN '".date("Y-m-d", strtotime($_POST["From"]))."' AND '".date("Y-m-d", strtotime($_POST["to"]))."' ";
//  AND `invoice_date` BETWEEN '".$_POST["From"]."' AND '".$_POST["to"]."'' 
}

}
if(isset($_POST['print'])){
  
  $v =$_POST['vendor'];
 $f =$_POST['From'];
 $t =$_POST['to'];
 echo "<script>window.open('vendor_statement.php?vendor_id=$v&from=$f&to=$t','_self')</script>";
 
}
$qry = mysqli_query($db, "SELECT * FROM `vendors`");
for ($vendor = array (); $row_2 = $qry->fetch_assoc(); $vendor[] = $row_2);
?>
<!DOCTYPE html>
<html lang="en">
<!-- BEGIN HEAD -->


<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="width=device-width, initial-scale=1" name="viewport" />
<meta name="description" content="Responsive Admin Template" />
<meta name="author" content="RedstarHospital" />
<title>JAGDAMBA PRINT LINE</title>
<!-- google font -->
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&amp;subset=all" rel="stylesheet" type="text/css" />
<!-- icons -->
<link href="../assets/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<!--bootstrap -->

<link href="../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<!-- Material Design Lite CSS -->
<link rel="stylesheet" href="../assets/material/material.min.css">
<link rel="stylesheet" href="css/material_style.css">
<!-- Theme Styles -->
<link href="css/theme_style.css" rel="stylesheet" id="rt_style_components" type="text/css" />
<link href="css/plugins.min.css" rel="stylesheet" type="text/css" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" />
<link href="css/theme-color.css" rel="stylesheet" type="text/css" />
<!-- favicon -->
<link rel="shortcut icon" href="img/favicon.ico" /> 
<style>
    
.nowrap {
    white-space: nowrap;
}
.ridge {
    border-style: ridge;
}
.col-sm-offset-12{margin-left:100%}.col-sm-offset-11{margin-left:91.66666667%}.col-sm-offset-10{margin-left:83.33333333%}.col-sm-offset-9{margin-left:75%}.col-sm-offset-8{margin-left:66.66666667%}.col-sm-offset-7{margin-left:58.33333333%}.col-sm-offset-6{margin-left:50%}.col-sm-offset-5{margin-left:41.66666667%}.col-sm-offset-4{margin-left:33.33333333%}.col-sm-offset-3{margin-left:25%}.col-sm-offset-2{margin-left:16.66666667%}.col-sm-offset-1{margin-left:8.33333333%}.col-sm-offset-0{margin-left:0}
</style>
</head>
<!-- END HEAD -->
<body class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-white white-sidebar-color logo-indigo">
<div class="page-wrapper">
<!-- start header -->
<div class="page-header navbar navbar-fixed-top">
<div class="page-header-inner ">
<!-- logo start -->
<div class="page-logo " style="padding: 0px 0px 0px 0px; background:white;">
<a href="dashboard.php">
<img src="logo1.png" style="width:70%; height:60px; margin-left:25px;"> </a>
</div>
<!-- logo end -->
<ul class="nav navbar-nav navbar-left in">
<li><a href="#" class="menu-toggler sidebar-toggler"><i class="icon-menu"></i></a></li>
</ul>

<!-- start mobile menu -->
<a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse">
<span></span>
</a>
<!-- end mobile menu -->
<!-- start header menu -->
<div class="top-menu">
<ul class="nav navbar-nav pull-right">
<!-- start language menu -->

<!-- end language menu -->
<!-- start notification dropdown -->

<!-- end notification dropdown -->
<!-- start message dropdown -->

<!-- start manage user dropdown -->
<li class="dropdown dropdown-user">
<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
 <?php 

$sqll = "SELECT photo  from profile_pic";
$queryl = $dbh -> prepare($sqll);
$queryl->execute();
$resultss=$queryl->fetchAll(PDO::FETCH_OBJ);
$cntt=1;
if($queryl->rowCount() > 0)
{
foreach($resultss as $rows) 
{ ?>   
<img alt="" class="img-circle " src="<?php echo $rows->photo;?>" />
<span class="username username-hide-on-mobile"> <?php echo $name; ?> </span>
<i class="fa fa-angle-down"></i>
</a>
<ul class="dropdown-menu dropdown-menu-default">



<li class="divider"> </li>

<li>
<a href="logout.php">
<i class="icon-logout"></i> Log Out </a>
</li>

<li>
<a href="changepassword.php">
<i class="icon-lock"></i> Change Password </a>
</li>
</ul>
</li>
<!-- end manage user dropdown -->

</ul>
</div>
</div>
</div>
<!-- end header -->

<!-- start page container -->
<div class="page-container">
<!-- start sidebar menu -->
<div class="sidebar-container">
<div class="sidemenu-container navbar-collapse collapse fixed-menu">
<div id="remove-scroll" class="left-sidemenu">
<ul class="sidemenu  page-header-fixed slimscroll-style" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
<li class="sidebar-toggler-wrapper hide">
<div class="sidebar-toggler">
<span></span>
</div>
</li>
<li class="sidebar-user-panel">
<div class="user-panel">
<div class="pull-left image">
<img src="<?php echo $rows->photo;?>" class="img-circle user-img-circle" alt="User Image" />
</div>
<div class="pull-left info">
<p><?php echo $name; ?> </p>
<a href="#"><i class="fa fa-circle user-online"></i><span class="txtOnline"> Online</span></a>
</div>
</div>
<?php } }
?>
</li>
<li class="nav-item start active open">
<a href="dashboard.php" class="nav-link nav-toggle">
<i class="material-icons">dashboard</i>
<span class="title">Dashboard</span>
<span class="selected"></span>

</a>

</li>

<li class="nav-item  ">
<a href="#" class="nav-link nav-toggle"><i class="material-icons">assignment</i>
<span class="title">Vendors</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item  ">
<a href="add_vendor.php" class="nav-link "> <span class="title"> Add Vendor</span>
</a>
</li>
<li class="nav-item  ">
<a href="view_vendor.php" class="nav-link "> <span class="title"> All Vendor</span>
</a>
</li>
<li class="nav-item  ">
<a href="view_vendor_product.php" class="nav-link "> <span class="title"> All Vendor Products</span>
</a>
</li>


</ul>
</li>

<li class="nav-item  ">
<a href="#" class="nav-link nav-toggle"><i class="material-icons">assignment</i>
<span class="title">Clients</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item  ">
<a href="add_client.php" class="nav-link "> <span class="title"> Add Clients</span>
</a>
</li>
<li class="nav-item  ">
<a href="view_client.php" class="nav-link "> <span class="title"> View Clients</span>
</a>
</li>
<li class="nav-item  ">
<a href="view_client_product.php" class="nav-link "> <span class="title"> All Clients Products</span>
</a>
</li>

</ul>
</li>

<li class="nav-item  ">
<a href="#" class="nav-link nav-toggle"><i class="material-icons">assignment</i>
<span class="title">Staff</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item">
<a href="add_staff.php" class="nav-link"> <span class="title"> Add Staff</span>
</a>
</li>
<li class="nav-item">
<a href="all_staff.php" class="nav-link"> <span class="title"> All Staff</span>
</a>
</li>
</ul>
</li>

<li class="nav-item">
<a href="#" class="nav-link nav-toggle"><i class="material-icons">assignment</i>
<span class="title">Expenses</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item">
<a href="add_expenses.php" class="nav-link "> <span class="title"> Add expenses</span>
</a>
</li>
<li class="nav-item">
<a href="all_expenses.php" class="nav-link"> <span class="title"> All expenses</span>
</a>
</li>


</ul>
</li>     
<li class="nav-item">
<a href="#" class="nav-link nav-toggle"><i class="material-icons">assignment</i>
<span class="title">Stock</span><span class="arrow"></span></a>
<ul class="sub-menu">
<!--purchase-->
<li class="nav-item">
<a href="#" class="nav-link nav-toggle">
<span class="title">Purchase</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item">
<a href="add_purchase.php" class="nav-link "> <span class="title">New Purchase</span>
</a>
</li>
<li class="nav-item">
<a href="purchase_list.php" class="nav-link"> <span class="title">Purchase List</span>
</a>
</li>
</ul>
</li>  
<!--end purchase-->
<!--product-->
<li class="nav-item">
<a href="#" class="nav-link nav-toggle">
<span class="title">Product</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item">
<a href="add_product.php" class="nav-link "> <span class="title">New Product</span>
</a>
</li>
<li class="nav-item">
<a href="product_list.php" class="nav-link"> <span class="title">Product List</span>
</a>
</li>
</ul>
</li>  
<!--end purchase-->
<!--purchase-->
<li class="nav-item">
<a href="#" class="nav-link nav-toggle">
<span class="title">Used</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item">
<a href="add_used.php" class="nav-link "> <span class="title">Add Used </span>
</a>
</li>
<li class="nav-item">
<a href="used_list.php" class="nav-link"> <span class="title">Used List</span>
</a>
</li>
</ul>
</li>  
<!--end purchase-->

</ul>
</li>






</ul>
</div>
</div>
</div>
<!-- end sidebar menu --> 
<!-- start page content -->
<div class="page-content-wrapper">
<div class="page-content">
<div class="page-bar">
<div class="page-title-breadcrumb">
<div class=" ">
<div class="page-title"><h2 style="text-align: center; "><font color="#21A6DE">Vendor Information</div></font>
 <div class="card card-topline-red" style="padding: 0px 0px 0px 0px;">
     <?php 

$sql = "SELECT * from  vendors WHERE vendor_id = $vendor_id";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $row) 
{ ?>
<?php } }
?>
    <!--row star-->
  <div class="row">

    <div class="col-sm-4">
      <span style="margin-left:38px; text-align: center;"><h4 style="border:2px solid #21A6DE; border-radius:25px; padding: 1px 52px 1px 1px; margin-left: 7px;"> Vendor Name:<b style="color: #0e95e6;"><?php echo htmlentities($row->vendor_name);?></b></h4></span>
    </div>
    <div class="col-sm-offset-3 col-sm-4">
        <span style="margin-left:38px; text-align: center;"><h4 style="border:2px solid #21A6DE;border-radius:25px;; "> Mobile No.:<b style="color: #0e95e6;"><?php echo htmlentities($row->mobile_no);?></b></h4></span>
        
    </div>
</div>
       
    

    <div class="row">

    <div class="col-sm-4">
        <span style="margin-left:38px;  text-align: center;   "><h4 style="border:2px solid #21A6DE;border-radius:25px;margin-left: 7px; ">  GST NO.: <b style="color: #0e95e6;"><?php echo htmlentities($row->gst_no);?></b> </h4></span>
    </div>
     <div class=" col-sm-offset-3 col-sm-4" >
       <span style=" ;padding-left: 130px; text-align: center;"><h4 style="border:2px solid #21A6DE;border-radius:25px;; ">  Address:<b style="color: #0e95e6;"><?php echo htmlentities($row->address);?></b></h4></span>

    </div>
    
    
  
    </div>
  </div>


</div>
<h5 style="color:red;">If there is some due amount(Balance Forward) You have to generate an invoice in order to maintain balanace sheet.</h5>
</div>
</div>
<div class="row">
<div class="col-md-12">
<div class="tabbable-line">
<!-- <ul class="nav nav-tabs">
<li class="active">
<a href="#tab1" data-toggle="tab"> List View </a>
</li>
<li>
<a href="#tab2" data-toggle="tab"> Grid View </a>
</li>
</ul> -->

<div class="tab-content">
<div class="tab-pane active fontawesome-demo" id="tab1">
<div class="row">
<div class="col-md-12">
<div class="card card-topline-red">
<div class="card-head">
<header></header>
<div class="tools">
<a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
<a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
<a class="t-close btn-color fa fa-times" href="javascript:;"></a>
</div>
</div>
<div class="card-body ">
<div class="row">
<div class="col-sm-2">

<a href="deposite_cash_vendor.php?edit=<?php echo $row->vendor_id ;?>"  class="btn btn-info">
Deposite Cash
</a>
</div>
<div class="col-sm-2">
<a href="add_invoice.php?edit1=<?php echo $row->vendor_id ;?>" class="btn btn-info">
Add Invoice 
</a>
</div>
<div class="col-sm-1">
<form action="function.php" method="post">
  
<a class="btn btn-info btn-action ecom-bg-csv m-l-10 pull-right" href="function.php?vendor_id=<?php echo $vendor_id ;?>" name="client"  style="margin-top: 1px;" >Export</a>

</form>
</div>
<div class="col-sm-7">
<form action="vendor_profile.php" method="post">
<div class="row">
<div class="col-sm-3">
<input type="text" name="From" id="fromDate" class="form-control" placeholder="From Date" />
</div>
<div class="col-sm-3" style="margin-left:5px;">
<input type="text" name="to" id="toDate" class="form-control" placeholder="To Date" />
</div>
<input type="hidden" name="vendor"  class="form-control" value="<?php echo $vendor_id; ?>" />

<div class="col-sm-2" style="padding:0px 0px 0px 12px;">
<button class="form-control btn btn-info"  type="submit" name="submit">Apply</button>
</div>
<div class="col-sm-3" style="padding:0px 0px 0px 12px;">
<button class="form-control btn btn-info"  type="submit" name="print">Print Statement</button>
</div>
</div>
</form>
</div>
</div>
<div class="row">

<div class="table-scrollable">
<table id="example4" class="table table-hover table-checkable order-column full-width" >
<thead>
<tr>
<th class="center">SR No.</th>
<th class="center">Invoice NO</th>
<th class="center">Invoice Date</th>
<th class="center">Total Amount</th>

<th class="center">Pay(In Rs.)</th>
<th class="center">Dues(In Rs.)</th>

<th class="center">Status</th>
<th class="center">Created Date</th>
<th class="center" style="width: 205px;">Action</th>


</tr>
</thead>
<?php 

$sql = "SELECT * from  vendor_invoice WHERE vendor_id = $vendor_id";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
$i=1;
if($query->rowCount() > 0)
{
foreach($results as $row) 
{ 
 ?>
<tbody>
<input type="hidden" value="<?php echo htmlentities($row->invoice_id);?>">
<td><?php echo $i++; ?></td>
<td class="center"><?php 
if($row->invoice_no==0){
    echo $row->invoice_no;
}else{
  echo htmlentities($row->invoice_no);  
}

?></td>  
<td class="center"><?php echo date("d-m-Y", strtotime($row->invoice_date)); ?></td>

<td class="center"><?php echo htmlentities($row->net_amount); 
$invtot = $row->invoice_total;
$invoice_n = $row->invoice_no;
$invoice_d = $row->invoice_date;
?></td>

<td class="center"><?php echo htmlentities($row->payble); ?></td>

<td class="center"><?php echo htmlentities($row->dues);?></td>
<td class="center"><?php echo htmlentities($row->status);?></td>
<td class="center"><?php $datee= $row->v_date; echo date('d-m-Y', strtotime($datee)) ?></td>
<?php 
if($invtot == 0 ){
    ?>
   <td style="color:red;" class="center" >
    
    <div class="dropdown" class="center">
         <button type="button" class="btn btn-info btn-xs gropdown-toggle center" data-toggle="dropdown">
Action<span class="caret"></span>
</button>
 <ul class="dropdown-menu dropdown-menu-right">
  <li>
<a href="edit_slip_vendor.php?edit1=<?php echo $row->invoice_id;?>"><i class="fa fa-edit"></i>Edit Bill</a>
</li>
 <li>
  <a href="delete_invoice.php?del=<?php echo $row->invoice_id;?>"><i class="fa fa-trash"></i>Delete Bill</a>
</li>   
</ul>
</div>
    
    </td>
<?php
}
else{
?>

<td style="color:red;" class="center">
  <div class="dropdown" class="center">
         <button type="button" class="btn btn-info btn-xs gropdown-toggle center" data-toggle="dropdown">
          Action<span class="caret"></span>
        </button>
<ul class="dropdown-menu dropdown-menu-right">
<li>
<a href="order_slip_vendor_final.php?edit1=<?php echo $row->invoice_id ;?>&name=staff"><i class="fa fa-edit"></i>
View Invoice
</a>
</li>
<li>
<a href="edit_slip_vendor.php?edit1=<?php echo $row->invoice_id;?>"><i class="fa fa-edit"></i>Edit Bill</a>
</li>
<li>
<a href="delete_invoice.php?del=<?php echo $row->invoice_id;?>"><i class="fa fa-trash"></i>Delete Bill</a>
</li>
    
</ul>
</div>
</td>
<?php  
}
?>


<?php  $duetotal = $row->total_due; ?> 
<?php  $finalduestatus = $row->status; ?>

<?php } }
?>
</tbody>
<tfoot>
<th class="center"></th>
<th class="center"></th>
<th class="center"></th>
<th class="center"></th>
<th class="center">Total Dues<br><b style="color: #0e95e6; font-size: 20px; display:inline;">
  <?php 
  //echo $row->pv_dues_remaining; 
  include_once 'config2.php';
  $sql=mysqli_query($db,"SELECT SUM(net_amount) AS tpaid,SUM(payble) AS tdue FROM `vendor_invoice` WHERE `vendor_id` ='$vendor_id'");
$row = mysqli_fetch_array($sql);
  $tp= $row['tpaid'];
  $td= $row['tdue'];
 $ttd =$tp-$td;
echo abs($ttd);
   ?>
    
  </b></th>
<th class="center"></th>
<th class="center"><?php 
if ($ttd>0) {
  echo "unpaid";
}else{
  echo "extra";
} ?></th>
<th class="center"></th>
<th class="center" style="width: 205px;"></th>   
</tfoot>
<tbody>

</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
<!-- end page content -->

</div>

<!-- end page container -->
<!-- start footer -->
<div class="page-footer">
<div class="page-footer-inner"> 2018 &copy; Jagdamba Management By
<a href="https://www.succexa.in" target="_top" class="makerCss">succexa</a>
</div>
<div class="scroll-to-top">
<i class="icon-arrow-up"></i>
</div>
</div>
<!-- end footer -->
</div>
<!-- start js include path -->
<script src="../assets/jquery.min.js" ></script>
<script src="../assets/popper/popper.js" ></script>
<script src="../assets/jquery.blockui.min.js" ></script>
<script src="../assets/jquery.slimscroll.js"></script>
<!-- bootstrap -->
<script src="../assets/bootstrap/js/bootstrap.min.js" ></script>
<script src="../assets/bootstrap-switch/js/bootstrap-switch.min.js" ></script>
<!-- data tables -->
<script src="../assets/datatables/jquery.dataTables.min.js" ></script>
<script src="../assets/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js" ></script>
<script src="../assets/table_data.js" ></script>
<!-- Common js-->
 <script src="../assets/app.js" ></script> 
<script src="../assets/layout.js" ></script>
<script src="../assets/theme-color.js" ></script>
<!-- Material -->
<script src="../assets/material/material.min.js"></script>
<!-- end js include path -->
</body>

<!-- Mirrored from radixtouch.in/templates/admin/redstar/source/light/all_doctors.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 26 Jun 2018 06:09:19 GMT -->
</html>