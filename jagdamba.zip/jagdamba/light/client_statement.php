<?php include "config.php"; ?>
<?php include "config2.php"; 
$v = $_GET['client_id'];
$f=$_GET['from'];
$t=$_GET['to'];

?>


<html>
    <head>
        <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/font.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        </head>
        <body>
          <div class="container">
              <h4 style="color:red; text-align:center;">!!Sri Ganeshay Namah !!</h4>
              <h2 style="color:red; text-align:center;">JAGDAMBA PRINT LINE</h2><h4 style="color:red; text-align:center;">D.N Das Lane,Bengali AkharaNear Langartoli More,Patna</h4><h4 style="color:red; text-align:center;">GSTIN:10AZNPP1854H1ZD</h4>
          </div>
          <div class="container">
              <div class="row">
                  <div class="col-sm-6" >
                        <h4 style="color:red;"><b>Client Statement</b></h4>
                        <?php 
                        $f1 = date("Y-m-d", strtotime($f));
                        $t1 = date("Y-m-d", strtotime($t));
                        $sql = "SELECT p.*,c.*,pm.* FROM `purchase_table`p INNER JOIN clients c ON c.client_id =p.client_id  INNER JOIN product_master pm ON pm.client_id=p.client_id WHERE c.client_id ='$v' LIMIT 1";
                        
                        $query = $dbh -> prepare($sql);
                        $query->execute();
                        $results=$query->fetchAll(PDO::FETCH_OBJ);
                        $cnt=1;
                        if($query->rowCount() > 0)
                        {
                        foreach($results as $rows) 
                        {
                        ?>
                        
                        <h5><b><?php echo htmlentities($rows->client_name); ?></b></h5>
                        <h5><b>GSTIN:<?php echo htmlentities($rows->gst_no); ?> </b></h5>
                        <h5><b>Address: <?php echo htmlentities($rows->address); ?></b></h5>
                          <?php } }?>
                 </div>
               
    <div class="col-sm-6" >
        <div style="margin-left:250px;">
         <h4>From <?php echo $f; ?> : To: <?php echo $t; ?></h4>
         </div>
    </div>
              </div>
          </div>
          <div class="container-fluid">
               <table class="table table-bordered">
    <thead>
      <tr>
        <th>Invoice No</th>
        <th>Date</th>
        <th>Client Name</th>
        <th>Amount</th>
        <!-- <th>GST%</th> -->
        <th>GST Amount</th>
        <th>Net Amount</th>
        <th>Paid Amount</th>
        <th>Payment Mode</th>
        <th>Cheque/UTR No.</th>
        <th>Account No</th>
      </tr>
    </thead>
    <tbody>
        <?php 
        // $originalDate = "2010-03-21";
        $f1 = date("Y-m-d", strtotime($f));
        $t1 = date("Y-m-d", strtotime($t));

              if (!$v==0 && !$f1==0){
                $sql = "SELECT p.*,p.purchase_id AS id,c.* FROM `purchase_table`p INNER JOIN clients c ON c.client_id =p.client_id WHERE datept BETWEEN '$f1' AND '$t1' AND c.client_id = '$v'";
              }
               if (!$v==0) {
                
                $sql = "SELECT p.*,p.purchase_id AS id,c.*  FROM `purchase_table`p INNER JOIN clients c ON c.client_id =p.client_id WHERE  c.client_id = '$v'";
              }
              if (!$f==0) {
                $sql = "SELECT p.*,p.purchase_id AS id,c.* FROM `purchase_table`p INNER JOIN clients c ON c.client_id =p.client_id WHERE datept BETWEEN '$f1' AND '$t1'";
              } 
                       

                        
                        $query = $dbh -> prepare($sql);
                        $query->execute();
                        $results=$query->fetchAll(PDO::FETCH_OBJ);
                        $cnt=1;
                        if($query->rowCount() > 0)
                        {
                        foreach($results as $row) 
                        { 
                            
                        ?>
      <tr>
        <td><?php 
        if(!$row->tsum==0){
           echo htmlentities($row->id); 
        }else{
            
            echo "Money receipt";
            
        }
        
         ?></td>
        <td><?php echo $t2 = date("d-m-Y", strtotime($row->datept)); ?></td>
        <td><?php echo htmlentities($row->client_name); ?></td>
        <td><?php echo htmlentities($row->tsum); ?></td>
        <!-- <td><?php 
        if(!$row->tsum==0){
           echo ""; 
        }else{
            
            echo "";
            
        }
        
         ?></td> -->
        <td><?php echo htmlentities($row->gst_total); ?></td>
        <td><?php echo htmlentities($row->net_amount); ?></td>
        <td><?php echo htmlentities($row->payble); ?></td>
        <td><?php echo htmlentities($row->payment_method); ?></td>
        <td><?php echo htmlentities($row->utr_no); ?></td>
        <td><?php 
        echo $row->deposite_account; ?></td>
         
      </tr>
      <?php } } ?>
    </tbody>
    <tfoot>
         <?php  
                 $f1 = date("Y-m-d", strtotime($f));
                $t1 = date("Y-m-d", strtotime($t));
                if (!$v==0) {
                
               $sql =mysqli_query($db,"SELECT SUM(p.tsum) AS total_net_amount,SUM(p.gst_total) AS total_gst_amount,SUM(p.payble) AS total_payble,SUM(p.net_amount) AS ntotal FROM `purchase_table`p INNER JOIN clients c ON c.client_id =p.client_id  WHERE c.client_id = '$v'");
              } elseif ($v==0) {
                $sql =mysqli_query($db,"SELECT SUM(p.tsum) AS total_net_amount,SUM(p.gst_total) AS total_gst_amount,SUM(p.payble) AS total_payble,SUM(p.net_amount) AS ntotal FROM `purchase_table`p INNER JOIN clients c ON c.client_id =p.client_id WHERE datept BETWEEN '$f1' AND '$t1'");
              }else{
                $sql =mysqli_query($db,"SELECT SUM(p.tsum) AS total_net_amount,SUM(p.gst_total) AS total_gst_amount,SUM(p.payble) AS total_payble,SUM(p.net_amount) AS ntotal FROM `purchase_table`p INNER JOIN clients c ON c.client_id =p.client_id WHERE datept BETWEEN '$f1' AND '$t1' AND c.client_id = '$v'");
              }
                      
                      $row =mysqli_fetch_array($sql);
                      ?>
      
       <th></th>
        <th></th>
        <th>Total</th>
        <th><?php echo $row['total_net_amount']; ?></th>
        <th></th>
        <th><?php echo $row['total_gst_amount']; ?></th>
        <th><?php echo $row['ntotal']; ?></th>
        <th><?php echo $row['total_payble']; ?></th>
        <th></th>
        <th></th>
       <!--  <th></th> -->
        <!-- <th></th> -->
        
    </tfoot>
     
  </table>
 
          </div>
        </body>
    
</html>
<script>
  window.print();
</script>