<?php
session_start();
// initializing variables
$username = "succeky5_succexa";
$password = "~f_uR)+v,*bS";
$errors = array();
// connect to the database
$db = mysqli_connect('localhost', 'succeky5_succexa', '~f_uR)+v,*bS', 'succeky5_jgdmba');
include('config.php');
if (isset($_POST['submit']))
{
// receive all input values from the form
$name = mysqli_real_escape_string($db, $_POST['name']);


$mobile_no = mysqli_real_escape_string($db, $_POST['mobile_no']);
$address = mysqli_real_escape_string($db, $_POST['address']);


// image file directory
// form validation: ensure that the form is correctly filled ...
// first check the database to make sure
// a user does not already exist with the same username and/or email
$user_check_query = "SELECT * FROM client_press WHERE mobile_no ='$mobile_no'  LIMIT 1";
echo "hello i am in checked position";
$result = mysqli_query($db, $user_check_query);
$user = mysqli_fetch_assoc($result);
if ($user)
{ // if user exists
if ($user['mobile_no'] === $mobile_no)
{

array_push($errors, "mobile_no already exist");

}
}


// Finally, register user if there are no errors in the form
$query = "INSERT INTO client_press (name,mobile_no,address) VALUES ('$name','$mobile_no','$address')";

mysqli_query($db, $query);


$_SESSION['success'] = "You are now logged in";

header('location:view_client_pres.php');
}  
?>
