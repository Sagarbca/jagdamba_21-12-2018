<?php
	include_once 'config2.php';

	$id = $_GET['del'];
	$delete_qry = mysqli_query($db,"DELETE FROM `client_press` WHERE id='$id'");
	if ($delete_qry) {
		
		echo "<script>alert('Deleted...')</script>";
        echo "<script>window.open('view_client_pres.php','_self')</script>";
	}

?>