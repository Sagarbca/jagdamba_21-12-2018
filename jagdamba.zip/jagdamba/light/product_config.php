<?php
session_start();
// initializing variables
$username = "root";
$password = "";
$errors = array();
// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'jagdamba_new');
if (isset($_POST['submit']))
{
// receive all input values from the form
$product_name = mysqli_real_escape_string($db, $_POST['product_name']);


// image file directory
// form validation: ensure that the form is correctly filled ...
// first check the database to make sure
// a user does not already exist with the same username and/or email
$user_check_query = "SELECT * FROM product WHERE product_name ='$product_name'  LIMIT 1";
echo "hello i am in checked position";
$result = mysqli_query($db, $user_check_query);
$user = mysqli_fetch_assoc($result);
if ($user)
{ // if user exists
if ($user['product_name'] === $product_name)
{

array_push($errors, "product_name already exist");

}
}


// Finally, register user if there are no errors in the form
$query = "INSERT INTO product (product_name) VALUES ('$product_name')";

mysqli_query($db, $query);


$_SESSION['success'] = "You are now logged in";

header('location:product_list.php');
}  
?>
