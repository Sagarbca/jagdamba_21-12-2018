<?php $purchase_id = $_GET['edit1']; ?>
<head>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
 
<style>
input[type="text"]{
    border-top: none !important;
    border-right: none !important;
    border-left: none !important;
    border-bottom: 1px dotted #2196f3 !important;
    box-shadow: none !important;
    -webkit-box-shadow: none !important;
    -moz-box-shadow: none !important;
    -moz-transition: none !important;
    -webkit-transition: none !important;
  }
  
  .heading{
    color: #2196f3;
}

.control{
padding-top:7px;
}

.reciept{
    border-top: 5px solid #2196f3;
    -webkit-box-shadow: 0px 5px 21px -2px rgba(0,0,0,0.47);
    -moz-box-shadow: 0px 5px 21px -2px rgba(0,0,0,0.47);
    box-shadow: 0px 5px 21px -2px rgba(0,0,0,0.47);
    margin-top: 10px;
  margin-bottom: 10px;
}
</style>
</head>
<center>
<div class="container">
<div class="reciept" style="
    width: 780px;
">
	<div class="row" style="margin-top:10px;">
     
      <!-- <center><u><h1 class="heading">Money Receipt</h1></u></center> -->
     
		  
	  
           <img src="logo1.png" style="
    float-left: -51px;
    height: 100px;
    margin-left: -467px;
">
		  
			<u><h1 class="heading" style="
    margin-top: -55px; 
">Money Receipt</h1></u>
			 
	 
		  
 
	</div>
	<br/>
	<?php
include 'config2.php'; 
$result = $db->query ( "SELECT p.*,c.* FROM purchase_table p
JOIN clients c ON c.client_id = p.client_id WHERE p.purchase_id = $purchase_id" );
$count = 0;

while ( $item = $result->fetch_assoc () ) {

?>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Cheque No.:</th>
        <th><?php echo $item['utr_no']; ?></th>
         
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Bank Name :</td>
        <td><?php echo $item['deposite_account']; ?></td>
       
      </tr>
      <tr>
        <td>Date :</td>
        <td><?php echo date("d-m-Y", strtotime($item['datept'])); ?></td>
        
      </tr>
      <tr>
        <td>Amount :</td>
        <td><?php echo $item['payble']; ?></td>
       
      </tr>
      <tr>
        <td>Client's Name :</td>
        <td><?php echo $item['client_name']; ?></td>
       
      </tr>
    </tbody>
  </table>
 <?php } ?>
			<br/>
			 
			<br/>
			 
	 
		</div>
	</div>
</center>
</div>
</div>
<script>
window.print();
</script>