<?php
session_start();
// initializing variables
$username = "root";
$password = "";
$errors = array();
// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'jagdamba');
if (isset($_POST['submit']))
{
// receive all input values from the form
$date = mysqli_real_escape_string($db, $_POST['date']);
$challan_no = mysqli_real_escape_string($db, $_POST['challan_no']);
$vendor_name = mysqli_real_escape_string($db, $_POST['vendor_name']);
$product_name = mysqli_real_escape_string($db, $_POST['product_name']);
$quantity = mysqli_real_escape_string($db, $_POST['quantity']);
$gsm = mysqli_real_escape_string($db, $_POST['gsm']);
$kg = mysqli_real_escape_string($db, $_POST['kg']);
$cost = mysqli_real_escape_string($db, $_POST['cost']);
$subtotal = mysqli_real_escape_string($db, $_POST['subtotal']);
$total = mysqli_real_escape_string($db, $_POST['total']);
// form validation: ensure that the form is correctly filled ...
// by adding (array_push()) corresponding error unto $errors array
//echo "hello2";
// Finally, register user if there are no errors in the form
$query = "INSERT INTO `purchase_stock`(`date`, `challan_no`, `vendor_name`, `product_name`, `quantity`, `gsm`, `kg`, `cost`, `subtotal`, `total`) VALUES ('$date','$challan_no','$vendor_name','$product_name','$quantity','$gsm','$kg','$cost','$subtotal','$total')";
echo $query;
mysqli_query($db, $query);
//echo "hello";
// $_SESSION['name'] = $username;
$_SESSION['success'] = "You are now logged in";
header('location:purchase_list.php');
}
?>