<?php 
include 'config.php';
include 'config2.php';
 $f=$_GET['from'];
 $t=$_GET['to'];
 $v=$_GET['client_id'];
?>
<html>
    <head>
        <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/font.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        </head>
        <body>
          <div class="container">
              <h4 style="color:red; text-align:center;">!!Sri Ganeshay Namah !!</h4>
              <h2 style="color:red; text-align:center;">PRESSCART</h2><h4 style="color:red; text-align:center;">D.N Das Lane,Bengali AkharaNear Langartoli More,Patna</h4><h4 style="color:red; text-align:center;"></h4>
          </div>
          <div class="container">
              <div class="row">
                  <div class="col-sm-6" >
                    <h4 style="color:red;"><b>Client Statement</b></h4>
                        <?php 
                        $f1 = date("Y-m-d", strtotime($f));
                        $t1 = date("Y-m-d", strtotime($t));
                        $sql =mysqli_query($db,"SELECT * FROM `client_press`  WHERE id='$v'");
                        
                      $row =mysqli_fetch_array($sql);
                        ?>
                        
                        <h5><b><?php echo htmlentities($row['name']); ?></b></h5>
                        <h5><b>Mobile No:<?php echo htmlentities($row['mobile_no']); ?> </b></h5>
                        <h5><b>Address: <?php echo htmlentities($row['address']); ?></b></h5>
                          
                 </div>
    <div class="col-sm-6" >
        <div style="margin-left:250px;">
         <h4>From <?php echo $f; ?> : To: <?php echo $t; ?></h4>
         </div>
    </div>
              </div>
          </div>
          <div class="container-fluid">
               <table class="table table-bordered">
    <thead>
      <tr>
      <!--  <th>Invoice No</th> -->
        <th>SL. No.</th>
        
        <th>Customer Name</th>
        <th>Total Amount</th>
        <th>Paid Amount</th>
        <th>Dues Amount</th>
        
        <th>Date</th>
      </tr>
    </thead>
    <?php if ($f!='') {
      ?>
      <tbody>
        <?php  
         $v=$_GET['client_id'];
        $f1 = date("Y-m-d", strtotime($f));
        $t1 = date("Y-m-d", strtotime($t));
        
          $sql =mysqli_query($db,"SELECT * FROM `purchase_pres` p INNER JOIN client_press c ON c.id=p.client_name WHERE p.client_name='$v' AND `date` BETWEEN '$f1' AND '$t1' ");
        
        
        
                      
                      while($row =mysqli_fetch_array($sql))
                      {
                      ?>
      <tr>
        <td><?php echo $row['purchase_id']; ?></td>
        
        <td><?php echo $row['name']; ?></td>
        <td><?php echo $row['total_amount']; ?></td>
        <td><?php echo $row['paid_amount']; ?></td>
         <td><?php echo $row['dues_amount']; ?></td>
         <td><?php echo  date("d-m-Y", strtotime($row['date'])); ?></td>
          
        
      </tr>
      <?php } ?>
    </tbody>
    <?php }else{
      ?>
      <tbody>
        <?php  
         $v=$_GET['client_id'];
        $f1 = date("Y-m-d", strtotime($f));
        $t1 = date("Y-m-d", strtotime($t));
        
          $sql =mysqli_query($db,"SELECT * FROM `purchase_pres` p INNER JOIN client_press c ON c.id=p.client_name WHERE p.client_name='$v' ");
        
        
        
                      
                      while($row =mysqli_fetch_array($sql))
                      {
                      ?>
      <tr>
        <td><?php echo $row['purchase_id']; ?></td>
        
        <td><?php echo $row['name']; ?></td>
        <td><?php echo $row['total_amount']; ?></td>
        <td><?php echo $row['paid_amount']; ?></td>
         <td><?php echo $row['dues_amount']; ?></td>
         <td><?php echo  date("d-m-Y", strtotime($row['date'])); ?></td>
          
        
      </tr>
      <?php } ?>
    </tbody>
    <?php } ?>
    <tfoot>
        <?php  
                      $f1 = date("Y-m-d", strtotime($f));
                        $t1 = date("Y-m-d", strtotime($t));
                        if ($f!='') {
                         $sql =mysqli_query($db,"SELECT sum(total_amount) AS total,sum(paid_amount) AS ptotal,sum(dues_amount) AS dtotal FROM `purchase_pres` p INNER JOIN client_press c ON c.id=p.client_name WHERE p.client_name='$v' AND `date` BETWEEN '$f1' AND '$t1' ");
                        }else{
                          $sql =mysqli_query($db,"SELECT sum(total_amount) AS total,sum(paid_amount) AS ptotal,sum(dues_amount) AS dtotal FROM `purchase_pres`p INNER JOIN client_press c ON c.id=p.client_name WHERE p.client_name='$v'");
                        }
        
                      $row =mysqli_fetch_array($sql);
                      ?>
       <!-- <th></th> -->
        <th></th>
        <th>Total</th>
        
       
        <th><?php echo $row['total']; ?></th>
        <th><?php echo $row['ptotal']; ?></th>
       <th><?php echo $row['dtotal']; ?></th>
        <th></th>
        
    </tfoot>
  </table>
          </div>
        </body>
    
</html>
<script>
  window.print();
</script>