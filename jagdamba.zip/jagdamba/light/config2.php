<?php
$servername = "localhost";
$username = "root";
$password = "";
$db1="jagdamba_new";
   //define('DB_SERVER', 'localhost');
   //define('DB_USERNAME', 'succeky5_succexa');
   //define('DB_PASSWORD', '~f_uR)+v,*bS');
   //define('DB_DATABASE', 'succeky5_jgdmba');
   $db = mysqli_connect($servername,$username,$password,$db1);
?>


