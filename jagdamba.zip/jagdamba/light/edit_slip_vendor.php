<?php
include("config2.php");
error_reporting(1);
session_start();
include 'config.php';
include 'config2.php';
//if($name = $_SESSION['name']) 
if ($_SESSION['name']=="") {
header('location:index.php');
}
$name=$_SESSION['name'];
$edit = $_GET['edit1'];
?>
<?php
//$update_id = $_GET['edit_form'];
$invoice_no = $_POST['invoice_no'];
$date_of_invoice = date("d-m-Y", strtotime($_POST['date_of_invoice']));
$itotal = $_POST['itotal'];
$gst = $_POST['gst'];
$cgst = $_POST['cgst'];
$cgst_amount = $_POST['cgst_amount'];
$sgst = $_POST['sgst'];
$sgst_amount = $_POST['sgst_amount'];
$igst = $_POST['igst'];
$igst_amount = $_POST['igst_amount'];
$gst_amount = $_POST['gst_amount'];
$net_amount = $_POST['net_amount'];
$payble = $_POST['payble'];
$dues = $_POST['dues'];


if (isset($_POST['submit'])) {
  
  
  $update_qry = mysqli_query($db,"UPDATE `vendor_invoice` SET `invoice_no`='$invoice_no',
  `invoice_date`='$date_of_invoice',`invoice_total`='$itotal',`gst`='$gst',`cgst`='$cgst',`cgst_amount`='$cgst_amount',`sgst`='$sgst',
  `sgst_amount`='$sgst_amount',`igst`='$igst',`igst_amount`='$igst_amount',`gst_amount`='$gst_amount',`net_amount`='$net_amount',`payble`='$payble',
  `dues`='$dues' WHERE invoice_id='$edit'");
if ($update_qry) {
  
   echo "<script>alert('Updated...')</script>";
        echo "<script>window.open('view_vendor_product.php','_self')</script>";

}

else{
 echo "<script>alert('Not updated')</script>";
  echo "<script>window.open('edit_slip_vendor.php?edit1=$edit','_self')</script>";
}

}

?>

<!DOCTYPE html>
<html lang="en">
<!-- BEGIN HEAD -->
<!-- Mirrored from radixtouch.in/templates/admin/redstar/source/light/schedule.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 26 Jun 2018 06:08:39 GMT -->
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="width=device-width, initial-scale=1" name="viewport" />
<meta name="description" content="Responsive Admin Template" />
<meta name="author" content="RedstarHospital" />
<title>JAGDAMBA PRINT LINE</title>
<!-- google font -->
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&amp;subset=all" rel="stylesheet" type="text/css" />
<!-- icons -->
<link href="../assets/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<!--bootstrap -->
<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
<link href="../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<!-- Material Design Lite CSS -->
<link rel="stylesheet" href="../assets/material/material.min.css">
<link rel="stylesheet" href="css/material_style.css">
<!-- Theme Styles -->
<link href="css/theme_style.css" rel="stylesheet" id="rt_style_components" type="text/css" />
<link href="css/plugins.min.css" rel="stylesheet" type="text/css" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/responsive.css" rel="stylesheet" type="text/css" />
<link href="css/theme-color.css" rel="stylesheet" type="text/css" />
<!-- favicon -->
<link rel="shortcut icon" href="img/favicon.ico" /> 
<style type="text/css">
	.validation-color{
		color: red;
	}
</style>
</head>
<!-- END HEAD -->
<body class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-white white-sidebar-color logo-indigo">
<div class="page-wrapper">
<!-- start header -->
<div class="page-header navbar navbar-fixed-top">
<div class="page-header-inner ">
<!-- logo start -->
<div class="page-logo " style="padding: 0px 0px 0px 0px; background:white;">
<a href="dashboard.php">
<img src="logo1.png" style="width:70%; height:60px; margin-left:25px;"> </a>
</div>
<!-- logo end -->
<ul class="nav navbar-nav navbar-left in">
<li><a href="#" class="menu-toggler sidebar-toggler"><i class="icon-menu"></i></a></li>
</ul>

<!-- start mobile menu -->
<a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse">
<span></span>
</a>
<!-- end mobile menu -->
<!-- start header menu -->
<div class="top-menu">
<ul class="nav navbar-nav pull-right">
<!-- start language menu -->

<!-- end language menu -->
<!-- start notification dropdown -->

<!-- end notification dropdown -->
<!-- start message dropdown -->

<!-- start manage user dropdown -->
<li class="dropdown dropdown-user">
<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
   
<img alt="" class="img-circle " src="<?php echo $rows->photo;?>" />
<span class="username username-hide-on-mobile"><?php echo $name; ?></span>
<i class="fa fa-angle-down"></i>
</a>
<ul class="dropdown-menu dropdown-menu-default">



<li class="divider"> </li>

<li>
<a href="logout.php">
<i class="icon-logout"></i> Log Out </a>
</li>
<li>
<a href="changepassword.php">
<i class="icon-lock"></i> Change Password </a>
</li>
</ul>
</li>
<!-- end manage user dropdown -->

</ul>
</div>
</div>
</div>
<!-- end header -->

<!-- start page container -->
<div class="page-container">
<!-- start sidebar menu -->
<div class="sidebar-container">
<div class="sidemenu-container navbar-collapse collapse fixed-menu">
<div id="remove-scroll" class="left-sidemenu">
<ul class="sidemenu  page-header-fixed slimscroll-style" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
<li class="sidebar-toggler-wrapper hide">
<div class="sidebar-toggler">
<span></span>
</div>
</li>
<li class="sidebar-user-panel">
<div class="user-panel">
<div class="pull-left image">
<img src="<?php echo $rows->photo;?>" class="img-circle user-img-circle" alt="User Image" />
</div>
<div class="pull-left info">
<p><?php echo $name; ?></p>
<a href="#"><i class="fa fa-circle user-online"></i><span class="txtOnline"> Online</span></a>
</div>
</div>

</li>
<li class="nav-item start active open">
<a href="dashboard.php" class="nav-link nav-toggle">
<i class="material-icons">dashboard</i>
<span class="title">Dashboard</span>
<span class="selected"></span>

</a>

</li>
<li class="nav-item  ">
<a href="#" class="nav-link nav-toggle"><i class="material-icons">assignment</i>
<span class="title">Vendors</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item  ">
<a href="add_vendor.php" class="nav-link "> <span class="title"> Add Vendor</span>
</a>
</li>
<li class="nav-item  ">
<a href="view_vendor.php" class="nav-link "> <span class="title"> All Vendor</span>
</a>
</li>
<li class="nav-item  ">
<a href="view_vendor_product.php" class="nav-link "> <span class="title"> All Vendor Products</span>
</a>
</li>


</ul>
</li>

<li class="nav-item  ">
<a href="#" class="nav-link nav-toggle"><i class="material-icons">assignment</i>
<span class="title">Clients</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item  ">
<a href="add_client.php" class="nav-link "> <span class="title"> Add Clients</span>
</a>
</li>
<li class="nav-item  ">
<a href="view_client.php" class="nav-link "> <span class="title"> View Clients</span>
</a>
</li>
<li class="nav-item  ">
<a href="view_client_product.php" class="nav-link "> <span class="title"> All Clients Products</span>
</a>
</li>

</ul>
</li>
<li class="nav-item  ">
<a href="#" class="nav-link nav-toggle"><i class="material-icons">assignment</i>
<span class="title">Staff</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item">
<a href="add_staff.php" class="nav-link"> <span class="title"> Add Staff</span>
</a>
</li>
<li class="nav-item">
<a href="all_staff.php" class="nav-link"> <span class="title"> All Staff</span>
</a>
</li>


</ul>
</li>

<li class="nav-item">
<a href="#" class="nav-link nav-toggle"><i class="material-icons">assignment</i>
<span class="title">Expenses</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item">
<a href="add_expenses.php" class="nav-link "> <span class="title"> Add expenses</span>
</a>
</li>
<li class="nav-item">
<a href="all_expenses.php" class="nav-link"> <span class="title"> All expenses</span>
</a>
</li>


</ul>
</li>





<!-- here the stocks sidebar start -->
<li class="nav-item">
<a href="#" class="nav-link nav-toggle"><i class="material-icons">assignment</i>
<span class="title">Stock</span><span class="arrow"></span></a>
<ul class="sub-menu">
<!--purchase-->
<li class="nav-item">
<a href="#" class="nav-link nav-toggle">
<span class="title">Purchase</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item">
<a href="add_purchase.php" class="nav-link "> <span class="title">New Purchase</span>
</a>
</li>
<li class="nav-item">
<a href="purchase_list.php" class="nav-link"> <span class="title">Purchase List</span>
</a>
</li>
</ul>
</li>  
<!--end purchase-->
<!--product-->
<li class="nav-item">
<a href="#" class="nav-link nav-toggle">
<span class="title">Product</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item">
<a href="add_product.php" class="nav-link "> <span class="title">New Product</span>
</a>
</li>
<li class="nav-item">
<a href="product_list.php" class="nav-link"> <span class="title">Product List</span>
</a>
</li>
</ul>
</li>  
<!--end purchase-->
<!--purchase-->
<li class="nav-item">
<a href="#" class="nav-link nav-toggle">
<span class="title">Used</span><span class="arrow"></span></a>
<ul class="sub-menu">
<li class="nav-item">
<a href="add_used.php" class="nav-link "> <span class="title">Add Used </span>
</a>
</li>
<li class="nav-item">
<a href="used_list.php" class="nav-link"> <span class="title">Used List</span>
</a>
</li>
</ul>
</li>  
<!--end purchase-->

</ul>
</li>






</ul>
</div>
</div>
</div>
<!-- end sidebar menu --> 
<!-- start page content -->
<body>

<div class="page-content-wrapper">
<div class="page-content">
<div class="page-bar">
<div class="page-title-breadcrumb">
<div class=" pull-left">
<div class="page-title">Edit Slip Vendor</div>
</div>
<ol class="breadcrumb page-breadcrumb pull-right">
<li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="dashboard.php">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
</li>
<li><a class="parent-item" href="dashboard.php">JAGDAMBA PRINT LINE</a>&nbsp;<i class="fa fa-angle-right"></i>
</li>
<li class="active">Edit Slip Vendor</li>
</ol>
</div>
</div>


<div class="tab-content">
<div class="tab-pane active fontawesome-demo" id="tab1">
<div class="row">
<div class="col-md-12">
<div class="card card-topline-red">
<div class="card-head">
<header></header>
<div class="tools">

</div>
</div>

</div>
</div>
</div>
</div>

</div>
<div class="row">
<div class="col-md-12 col-sm-12">
<div class="card card-box">


<div class="card-body" id="bar-parent">
	<?php
if (isset($_GET['edit1'])) {
$vendor_id = $_GET['edit1'];
}
$sql = "SELECT vi.*,v.* FROM `vendor_invoice` vi INNER JOIN vendors v ON v.vendor_id=vi.vendor_id WHERE invoice_id ='$edit'";
$query = mysqli_query($db,$sql);
//$query->execute();
//$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if(mysqli_num_rows($query) > 0)
{
while($row = mysqli_fetch_array($query)) 
{
?>
<form action="" method="post" id="form_sample_1" class="form-horizontal">

<br>
<br>


<h1 class="center"><u>   </u></h1>
<br>
<br>
<div class="form-group row">
<label class="control-label col-md-3">Invoice No.
<span class="required"> * </span>
</label>
<div class="col-md-5">
<input type="text" name="invoice_no" data-required="1" 
placeholder="Enter Invoice No"  autofocus class="form-control input-height" required value='<?php echo $row['invoice_no'];?>' readonly /> </div>
</div>


<div class="form-body">
<div class="form-group row">
<label class="control-label col-md-3">Date                                                                                            
<span class="required"> * </span>
</label>
<div class="col-md-5">
<input type="text" name="date_of_invoice" data-required="1" id="datepicker" 
placeholder="DD-MM-YYYY" class="form-control input-height" required value='<?php echo date("d-m-Y", strtotime($row['invoice_date']));?>' /> </div>
</div>
</div>


<div class="form-group row">
<label class="control-label col-md-3">Invoice Total(₹) :
<span class="required"> * </span>
</label>
<div class="col-md-5">
<input type="text" name="itotal" id="itotal" class="itotal form-control input-height" 
value='<?php echo $row['invoice_total'];?>'> </div>
</div>


<hr>
<div class="form-group row">
<label class="control-label col-md-3">GST (%) :
<span class="required"> * </span>
</label>
<div class="col-md-5">
<input type="text" name="gst" id="gst" class="gst form-control input-height" value='<?php echo $row['gst'];?>'> </div>
</div>


<div class="form-group row">
<label class="control-label col-md-3">IGST (%) :
</label>
<div class="col-md-5">
<input type="text" name="igst" id="igst" class="igst form-control input-height" value='<?php echo $row['igst'];?>'> </div>
</div>


<input type="hidden" name="cgst" class="cgst">
<input type="hidden" name="cgst_amount" class="cgst_amount">
<input type="hidden" name="sgst" class="sgst">
<input type="hidden" name="sgst_amount" class="sgst_amount">
<input type="hidden" name="igst" class="igst">
<input type="hidden" name="igst_amount" class="igst_amount">
<input type="hidden" name="gst_amount" class="gst_amount">

<hr>

<div class="form-body">
<div class="form-group row">
<label class="control-label col-md-3">Net Amount
<span class="required"> * </span>
</label>
<div class="col-md-5">
<input name="net_amount" type="text" placeholder="Net Amaount" class="net_amaount form-control input-height" 
readonly value='<?php echo $row['net_amount'];?>' /> </div>
</div>
</div>

<div class="form-body">
<div class="form-group row">
<label class="control-label col-md-3">Payable
<span class="required"> * </span>
</label>
<div class="col-md-5">
<input name="payble" type="text" placeholder="Payable" class="form-control input-height payable" 
value='<?php echo $row['payble'];?>'/> </div>
</div>
</div>
<?php 
if ($row['invoice_total'] > 0) {
  ?>
  <div class="form-group row">
<label class="control-label col-md-3">Dues
<span class="required"> * </span>
</label>
<div class="col-md-5">
<input name="dues" type="text" placeholder="Dues" class="form-control input-height dues" 
readonly value='<?php echo $row['dues'];?>'/> </div>
</div>
<?php }else{
  ?>
<?php }

 ?>



<div class="form-actions">
<div class="row">
<div class="offset-md-3 col-md-9">
<button type="submit" name="submit" class="btn btn-info">update</button>
<a class="btn btn-danger" href="view_vendor_product.php">Cancel</a>

</div>
</div>

</div>

</div>
</div>
</form>
<?php } } ?>
</div>
</div>
</div>
</div>

</div>
</div>

<!-- end page content -->

</div>
<!-- end page container -->
<!-- start footer -->
<div class="page-footer">
<div class="page-footer-inner"> 2018 &copy;  Jagdamba Management By
<a href="https://www.succexa.in/" target="_top" class="makerCss">succexa</a>
</div>
<div class="scroll-to-top">
<i class="icon-arrow-up"></i>
</div>
</div>
<!-- end footer -->
</div>
<!-- start js include path -->
<script src="../assets/jquery.min.js" ></script>
<script src="../assets/popper/popper.js" ></script>
<script src="../assets/jquery.blockui.min.js" ></script>
<script src="../assets/jquery-validation/js/jquery.validate.min.js" ></script>
<script src="../assets/jquery-validation/js/additional-methods.min.js" ></script>
<script src="../assets/jquery.slimscroll.js"></script>
<!-- bootstrap -->
<script src="../assets/bootstrap/js/bootstrap.min.js" ></script>
<script src="../assets/bootstrap-switch/js/bootstrap-switch.min.js" ></script>
<script src="../assets/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"  charset="UTF-8"></script>
<script src="../assets/bootstrap-datetimepicker/js/bootstrap-datetimepicker-init.js"  charset="UTF-8"></script>
<!-- Common js-->
<script src="../assets/app.js" ></script>
<script src="../assets/form-validation.js" ></script>
<script src="../assets/layout.js" ></script>
<script src="../assets/theme-color.js" ></script>
<!-- Material -->
<script src="../assets/material/material.min.js"></script>
<!-- end js include path -->
<script>


$(document).ready(function() {

$(".allow_only_int").keydown(function(e) {
// Allow: backspace, delete, tab, escape, enter and .
if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
// Allow: Ctrl+A,Ctrl+C,Ctrl+V, Command+A
((e.keyCode == 65 || e.keyCode == 86 || e.keyCode == 67) && (e.ctrlKey === true || e.metaKey === true)) ||
// Allow: home, end, left, right, down, up
(e.keyCode >= 35 && e.keyCode <= 40)) {

// let it happen, don't do anything

}
// Ensure that it is a number and stop the keypress
if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
e.preventDefault();
}
});

$(".allow_only_num").keydown(function(e) {
// Allow: backspace, delete, tab, escape, enter and both .
if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
// Allow: Ctrl+A,Ctrl+C,Ctrl+V, Command+A
((e.keyCode == 65 || e.keyCode == 86 || e.keyCode == 67) && (e.ctrlKey === true || e.metaKey === true)) ||
// Allow: home, end, left, right, down, up
(e.keyCode >= 35 && e.keyCode <= 40)) {
// let it happen, don't do anything
return;
}
// Ensure that it is a number and stop the keypress
if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
e.preventDefault();
}
});




//var gggg =  $( "input[name*='product_name1']" ).val();
//$( "input[name*='product_name1']" ).val( "has man in it!" );
// alert(gggg);




});




</script>


<script>
  $(document).ready(function(){
    var client_name_empty = "Please Enter the Client Name.";
    var client_name_invalid = "Please Enter Valid Client Name";
    var client_name_length = "Please Enter Client Name Minimun 3 Character";
    $("#submit").click(function(event){
      var name_regex = /^[-a-zA-Z\s]+$/;
      var mobile_regex = /^[6-9][0-9]{9}$/; 
      var email_regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
      var state_regex = /^[-a-zA-Z\s]+$/;
      var state_code_regex = /^[0-9][0-9]{1}$/; 
      var client_name = $('#client_name').val().trim();
      var mobile = $('#mobile').val();
      var email = $('#email').val();
      var state = $('#state').val();
      var state_code = $('#state_code').val();
      $('#client_name').val(client_name);
      if(client_name==null || client_name==""){
        $("#err_client_name").text(client_name_empty);
        return false;
      }
      else{
        $("#err_client_name").text("");
      }
      if (!client_name.match(name_regex) ) {
        $('#err_client_name').text(client_name_invalid);   
        return false;
      }
      else{
        $("#err_client_name").text("");
      }
      if (client_name.length < 3) {
        $('#err_client_name').text(client_name_length);  
        return false;
      }
      else{
        $("#err_client_name").text("");
      }
//client name validation complite.
if(mobile==null || mobile==""){
          $("#err_mobile").text("Please Enter Mobile.");
          return false;
        }
        else{
          $("#err_mobile").text("");
        }
        if (!mobile.match(mobile_regex) ) {
          $('#err_mobile').text(" Please Enter Valid Mobile ");   
          return false;
        }
        else{
          $("#err_mobile").text("");
        }
//mobile validation complite.
if(email==null || email==""){
          $("#err_email").text("Please Enter Email.");
          return false;
        }
        else{
          $("#err_email").text("");
        }
        if (!email.match(email_regex) ) {
          $('#err_email').text(" Please Enter Valid Email Address ");   
          return false;
        }
        else{
          $("#err_email").text("");
        }
//email validation complite.
if(state==null || state==""){
          $("#err_state").text("Please Enter State.");
          return false;
        }
        else{
          $("#err_state").text("");
        }
        if (!state.match(state_regex) ) {
          $('#err_state').text(" Please Enter Valid State Name ");   
          return false;
        }
        else{
          $("#err_state").text("");
        }
//State validation complite.
if(state_code==null || state_code==""){
          $("#err_state_code").text("Please Enter State code.");
          return false;
        }
        else{
          $("#err_state_code").text("");
        }
        if (!state_code.match(state_code_regex) ) {
          $('#err_state_code').text(" Please Enter Valid State Code ");   
          return false;
        }
        else{
          $("#err_state_code").text("");
        }
//State Code validation complite.
    });

    $("#client_name").on("blur keyup",  function (event){
      var name_regex = /^[-a-zA-Z\s]+$/;
      var client_name = $('#client_name').val();
        if(client_name==null || client_name==""){
          $("#err_client_name").text(client_name_empty);
          return false;
        }
        else{
          $("#err_client_name").text("");
        }
        if (!client_name.match(name_regex)) {
          $('#err_client_name').text(client_name_invalid);  
          return false;
        }
        else{
          $("#err_client_name").text("");
        }
        if (client_name.length < 3) {
          $('#err_client_name').text(client_name_length);  
          return false;
        }
        else{
          $("#err_client_name").text("");
        }
    });
    $("#mobile").on("blur keyup",  function (event){
        var mobile_regex = /^[6-9][0-9]{9}$/;
        var mobile = $('#mobile').val();
        $('#mobile').val(mobile);
        if(mobile==null || mobile==""){
          $("#err_mobile").text("Please Enter Mobile.");
          return false;
        }
        else{
          $("#err_mobile").text("");
        }
        if (!mobile.match(mobile_regex) ) {
          $('#err_mobile').text(" Please Enter Valid Mobile ");   
          return false;
        }
        else{
          $("#err_mobile").text("");
        }
        
    });
    $("#email").on("blur keyup",  function (event){
        var email_regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        var email = $('#email').val();
        $('#email').val(email);
        if(email==null || email==""){
          $("#err_email").text("Please Enter Email.");
          return false;
        }
        else{
          $("#err_email").text("");
        }
        if (!email.match(email_regex) ) {
          $('#err_email').text(" Please Enter Valid Email Address ");   
          return false;
        }
        else{
          $("#err_email").text("");
        }
    });
    $("#state").on("blur keyup",  function (event){
        var state_regex = /^[-a-zA-Z\s]+$/;
        var state = $('#state').val();
        $('#state').val(state);
        if(state==null || state==""){
          $("#err_state").text("Please Enter State.");
          return false;
        }
        else{
          $("#err_state").text("");
        }
        if (!state.match(state_regex) ) {
          $('#err_state').text(" Please Enter Valid State Name ");   
          return false;
        }
        else{
          $("#err_state").text("");
        }
        
    });
    $("#state_code").on("blur keyup",  function (event){
        var state_code_regex = /^[0-9][0-9]{1}$/;
        var state_code = $('#state_code').val();
        $('#state_code').val(state_code);
        if(mobile==null || mobile==""){
          $("#err_state_code").text("Please Enter state code.");
          return false;
        }
        else{
          $("#err_state_code").text("");
        }
        if (!state_code.match(state_code_regex) ) {
          $('#err_state_code').text(" Please Enter Valid state code ");   
          return false;
        }
        else{
          $("#err_state_code").text("");
        }
        
    });
   
}); 
</script>
</body>


</html>
<script>


$(document).ready(function(){

$(".hide").hide();


//on keypress

$(document).on('keyup', ".next,.discount,.payable,.gst,.igst,.itotal", function() {


//getting values from out side form
var itotal = $(".itotal").val();
var payable = $(".payable").val();
var gst = $(".gst").val();
var gstp =gst; 
var igst = $(".igst").val();
var igstp =igst;
itotal = parseFloat(itotal);


if(gst==undefined||gst=='')
{
    gst=parseFloat(0);
}
else{

    gst = itotal*parseFloat(gst)/100;
}

if(igst==undefined||igst=='')
{
    igst=parseInt(0);
}
else{

    igst = itotal*parseFloat(igst)/100;
}



var net_amaount =  parseFloat(itotal)+parseFloat(gst)+parseFloat(igst);

$(".net_amaount").val(net_amaount.toFixed(2));

var dues = 0;
var payment_mode = $(".payment_mode").val();
var deposite_account = $(".deposite_account").val();

//$(".tsum").val(tsum.toFixed(2));

dues = net_amaount-payable;

$('.dues').val(dues.toFixed(2));




/*hidden data */

$('.cgst').val((gstp/2));
$('.cgst_amount').val((gst/2).toFixed(2));
$('.sgst').val((gstp/2));
$('.sgst_amount').val((gst/2).toFixed(2));


    $('.igst').val(igstp);




//alert(igstp);
$('.igst_amount').val((igst).toFixed(2));

$('.gst_amount').val((gst+igst).toFixed(2));



});





});
</script>
<script>
        $(function(){
    $("#datepicker").datepicker({
        dateFormat: "dd-mm-yy"
    });
});
    </script>