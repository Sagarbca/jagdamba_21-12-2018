<?php $output = NULL;?>
<?php
include 'config.php';
//$mysqli = NEW Mysqli('localhost','root','','jagdamba');
//$mysqli = NEW Mysqli('localhost','succeky5_succexa','~f_uR)+v,*bS','succeky5_jgdmba');
if (isset($_POST['submit']))
{
	$date = $_POST['date'];
$f = date("Y-m-d", strtotime($date));
$date = date("Y-m-d", strtotime($date));


 $product_name = $_POST['product_name'];



$quantity = $_POST['quantity'];
$rim = $_POST['rim'];
$kg = $_POST['kg'];
$cost = $_POST['cost'];
$subtotal = $_POST['subtotal'];
$totalPrice = $_POST['totalPrice'];
//========================client press===
// $query1 = "INSERT INTO `client_press`(`name`, `mobile_no`, `address`)  VALUES ('$client_name','$mobile_no','$address')";
// echo $query;
// $insert1 = $mysqli->query($query1);
// // getting client id
// $sql=$mysqli->query("SELECT * FROM client_press where name='$client_name'");
// $data2=mysqli_fetch_assoc($sql);
// $idd = $data2['id'];
//==============================
//=========================================
//$date = date("d-m-Y");
$query_purchase = "INSERT INTO `purchase_used_stock`(`date`,  `total`)  VALUES ('$f','$totalPrice')";
echo $query_purchase;
$insert3 = $mysqli->query($query_purchase);
//========================================
//========================================
$querycount = "SELECT max(purchase_id) AS 'count' FROM purchase_used_stock ";
$insertcount = $mysqli->query($querycount);
// to count the no of rows 
$data1=mysqli_fetch_assoc($insertcount);
$purchase_id =  $data1['count'];
//========================================
foreach($product_name AS $key => $value){
$query = "INSERT INTO `product_used_stock`(`purchase_id`, `product_name`,`quantity`, `rim`, `kg`, `cost`, `subtotal`)  VALUES ('".$mysqli->real_escape_string($purchase_id)."','".$mysqli->real_escape_string($product_name[$key])."','".$mysqli->real_escape_string($quantity[$key])."','".$mysqli->real_escape_string($rim[$key])."','".$mysqli->real_escape_string($kg[$key])."','".$mysqli->real_escape_string($cost[$key])."','".$mysqli->real_escape_string($subtotal[$key])."')";
echo $query;
//mysqli_query($, $query);
$insert = $mysqli->query($query);
$sql="SELECT * FROM product WHERE product_name='$product_name[$key]'";
$insert1 = $mysqli->query($sql);
$row =$insert1->fetch_array() ;
	$q=$row['quantity'];
	 $q;
	 $q3= $quantity[$key];
	 $q2=$q-$q3;
$k=$row['kg'];
	 $k;
	 $k3= $kg[$key];
	 $k2=$k-$k3;
$r=$row['rim'];
	 $r;
	$r3= $rim[$key];
	 $r2=$r-$r3;
 $sql="UPDATE `product` SET `quantity`='$q2',`kg`='$k2',`rim`='$r2' WHERE product_name='$product_name[$key]'";
$insert = $mysqli->query($sql);
}

// my code ends here 

echo "<script>window.open('used_list.php','_self')</script>";
}
?>