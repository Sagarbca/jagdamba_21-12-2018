<?php 
include 'config.php';
//$mysqli = NEW Mysqli('localhost','succeky5_succexa','~f_uR)+v,*bS','succeky5_jgdmba');

$cgst_sum = 0;  $sgst_sum = 0;  $igst_sum = 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>CSS Template</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  width: 95%;
  font-family: Arial, Helvetica, sans-serif;
}

/* Style the header */
header {
  
  
  text-align: center;
  font-size: 35px;
  color: white;
}

/* Create two columns/boxes that floats next to each other */
nav {
  float: left;
  width: 30%;
  height: 300px; /* only for demonstration, should be removed */
  background: #ccc;
  padding: 20px;
}

/* Style the list inside the menu */
nav ul {
  list-style-type: none;
  padding: 0;
}



/* Clear floats after the columns */
section:after {
  content: "";
  display: table;
  clear: both;
}

/* Style the footer */
footer {
  
 height:284px\
 ;
  text-align: center;
  color: white;
}
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #e86c14;
  color: white;
}

/* Responsive layout - makes the two columns/boxes stack on top of each other instead of next to each other, on small screens */
@media (max-width: 600px) {
  nav, article {
    width: 100%;
    height: auto;
  }
}
</style>
</head>
<body>
<?php  //$name=$_SESSION['name'];
$purchase_id = $_GET['edit1']; ?>

<header>
  <img src="img/quotation1.jpg" alt="" style="width: 95%;">
</header>

<section style="width: 95%;">
 <?php
include 'config2.php'; 
$result = $db->query ( "SELECT p.*,
c.* 
FROM quotation p
JOIN clients c ON c.client_id = p.client_id WHERE p.purchase_id = $purchase_id" );
$count = 0;

while ( $item = $result->fetch_assoc () ) {

?>
<div class="col-sm-6" style="text-align: right;">
    <span style="padding: 26px;">Date: <?php  $datee= $item['datept']; echo date('d-m-Y', strtotime($datee)) ?> </span>
  </div>
 <div class="col-sm-6" style="margin-left: 35px;">
  <span>Ref: JPL-<?php echo $item['purchase_id']; ?>/18-19 </span><br>
    To,
<br>
<span style="font-weight: bold;"><?php echo strtoupper($item['client_name']);  ?></span> <br>
<span style="font-weight: bold;"><?php echo substr($item['address'],0,40);  ?></span> <br>
<span style="font-weight: bold;"><?php echo substr($item['address'],40,60);  ?></span>
<br>
 <span style="font-weight: bold;">GSTIN: <?php echo $item['gst_no'];  ?></span><br>
  </div>
  
<?php } ?>
  <div class="col-sm-12" style="margin-left: 35px;">
    <h3 style="text-align: center;">Subject:Quotation for Designing Printing & Supply of Poster</h3>
    <h3>Sir,</h3>
    <p>With reference to your kind inquiry for your Printing.We take pleasure in forwarding here with our lowest rate as per details given below:-
    </p></div>
      <div class="col-sm-12" style="margin-bottom: 0px;margin-left: 35px;" >
        <table id="customers">
     <tr>
      <th>S.NO</th>
      <th>PARTICULAR</th>
       <th>HSN CODE</th>
      <th>SPECIFICATION</th>
      <th>PaperSIZE</th>
      <th>QTY[Min]</th>
      <th>RATE[Each]</th>
      <th>GST</th>
     </tr>
     <?php
include 'config2.php'; 
$result = $db->query (" SELECT * FROM quotation_product WHERE purchase_id = '$purchase_id';");
$sn_no = 0;
while ($item1 = $result->fetch_assoc ()) {

$sn_no = $sn_no + 1;

?>
      <tr>
        <td><?php echo $sn_no; ?></td>
    <td><?php echo $item1['product_name']; ?></td>
    <td><?php echo $item1['hsn_code']; ?></td>
    <td><?php echo $item1['per']; ?></td>
    <td><?php echo $item1['amount']; ?></td>
    <td><?php echo $item1['quantity']; ?></td>
    <td><?php echo $item1['rate']; ?></td>
     <td><?php echo $item1['gst']; ?></td>
  </tr>
<?php } ?>
   </table>
   <!-- <P style="margin-left: 665px;">SGST6%+CGST6%=Total GST12% Extra</P> -->
    </div>
    <div class="col-sm-12" style="margin-left: 35px;">
      <p>Rate can vary as per size and quality and special instruction required by you.<br></p>
        <p>Hope you will find our rate quiet reasonable,competitive & favoured us with your valued order.</p>
          <b><p>Payment Condition:</b> Payment should be favoured in <b>JAGDAMBA PRINT LINE</b></p>
          <b><p>Note:</b> up to(+/_)5% variable in quantity / size color from art work & paper (gsm / weight)<br>
           <p style="margin-left: 48px;">: Delivery time 4-5 days after creative and PO.</p><br>
            Thanking you,<br><br>
            Your's Truly,<br>
            For <b>JAGDAMBA PRINT LINE</b>
          </p>

      </div>
</section>

<footer>
  <img src="img/quotation.jpg" alt="" style="width: 95%;">
</footer>

</body>
</html>
<script>
window.print();
</script>