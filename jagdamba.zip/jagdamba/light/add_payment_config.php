<?php
ini_set('display_errors', '1');
session_start();
// initializing variables
include('config.php');
include('config2.php');

if (isset($_POST['submit']))
{
// receive all input values from the form
$purchase_id = mysqli_real_escape_string($db, $_POST['purchase_id']);
$date = mysqli_real_escape_string($db, $_POST['date']);
//$ref_no = mysqli_real_escape_string($db, $_POST['ref_no']);
$invoive_amount = mysqli_real_escape_string($db, $_POST['invoive_amount']);
$paid_amount = mysqli_real_escape_string($db, $_POST['paid_amount']);
$dues_amount = mysqli_real_escape_string($db, $_POST['dues_amount']);
$pay_by = mysqli_real_escape_string($db, $_POST['pay_by']);
$bank_name = mysqli_real_escape_string($db, $_POST['bank_name']);
$cheque_no = mysqli_real_escape_string($db, $_POST['cheque_no']);

// image file directory
// form validation: ensure that the form is correctly filled ...
// first check the database to make sure
// a user does not already exist with the same username and/or email

echo "hello2";

// Finally, register user if there are no errors in the form
$query = "UPDATE `purchase_pres` SET `date`= '$date',`total_amount`= '$invoive_amount',`paid_amount`='$paid_amount',`dues_amount`= '$dues_amount',`pay_by`= '$pay_by',`bank_name`= '$bank_name',`cheque_no`= '$cheque_no' WHERE  `purchase_id` = '$purchase_id'";

echo $query;
mysqli_query($db, $query);


$_SESSION['success'] = "You are now logged in";

//header('location:all_expenses.php');
echo "<script>alert('payment added successfully')</script>";
echo "<script>window.open('sale_list_pres.php','_self')</script>";

}  
?>
