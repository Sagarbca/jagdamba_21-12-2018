<?php
header('invoice2.php');

?>