<?php $output = NULL;?>
<?php
include 'config.php';
//$mysqli = NEW Mysqli('localhost','root','','jagdamba');
//$mysqli = NEW Mysqli('localhost','succeky5_succexa','~f_uR)+v,*bS','succeky5_jgdmba');
if (isset($_POST['submit']))
{
$client_name = $_POST['client_name'];
// $mobile_no = $_POST['mobile_no'];
// $address = $_POST['address'];
$date = $_POST['date'];
$f = date("Y-m-d", strtotime($date));
$date = date("Y-m-d", strtotime($date));
$product_name = $_POST['product_name'];
$quantity_of_paper = $_POST['quantity_of_paper'];
$quantity = $_POST['quantity'];
$per = $_POST['per'];
$rate = $_POST['rate'];
$amount = $_POST['amount'];
$total_amount = $_POST['totalPrice'];
$paid_amount = $_POST['paid_amount'];
$dues_amount = $_POST['dues_amount'];
//========================client press===

// getting client id
$sql=$mysqli->query("SELECT * FROM client_press where name='$client_name'");
$data2=mysqli_fetch_assoc($sql);
$idd = $data2['id'];
//==============================
//=========================================
//$date = date("d-m-Y");
$query_purchase = "INSERT INTO `purchase_pres`(`date`, `client_name`, `total_amount`, `paid_amount`, `dues_amount`)  VALUES ('$f','$idd','$total_amount','$paid_amount','$dues_amount')";
echo $query_purchase;
$insert3 = $mysqli->query($query_purchase);
//========================================
//========================================
$querycount = "SELECT max(purchase_id) AS 'count' FROM purchase_pres ";
$insertcount = $mysqli->query($querycount);
// to count the no of rows 
$data1=mysqli_fetch_assoc($insertcount);
$purchase_id =  $data1['count'];
//========================================
foreach($product_name AS $key => $value){
$query = "INSERT INTO `product_pres`(`purchase_id`, `product_name`,`quantity_of_job`, `quantity`, `per`, `rate`, `amount`)  VALUES ('".$mysqli->real_escape_string($purchase_id)."','".$mysqli->real_escape_string($product_name[$key])."','".$mysqli->real_escape_string($quantity_of_paper[$key])."','".$mysqli->real_escape_string($quantity[$key])."','".$mysqli->real_escape_string($per[$key])."','".$mysqli->real_escape_string($rate[$key])."','".$mysqli->real_escape_string($amount[$key])."')";
echo $query;
//mysqli_query($, $query);
$insert = $mysqli->query($query);
}
// my code ends here 

echo "<script>window.open('sale_list_pres.php','_self')</script>";
}
?>