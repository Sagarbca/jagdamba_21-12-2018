<?php
session_start();
// initializing variables
$username = "root";
$password = "";
$errors = array();
// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'jagdamba_new');
if (isset($_POST['submit']))
{
// receive all input values from the form
$id = mysqli_real_escape_string($db, $_POST['id']);
$name = mysqli_real_escape_string($db, $_POST['name']);
$mobile_no = mysqli_real_escape_string($db, $_POST['mobile_no']);
$address= mysqli_real_escape_string($db, $_POST['address']);
$query = "UPDATE  client_press SET name = '$name',mobile_no = '$mobile_no',address = '$address' WHERE id = $id";
//echo $query;
mysqli_query($db, $query);
echo $query;

$_SESSION['success'] = "You are now logged in";
header('location:view_client_pres.php');
}
?>
