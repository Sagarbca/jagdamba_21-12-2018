<?php
	include_once 'config2.php';

	$id = $_GET['del'];
	$delete_qry = mysqli_query($db,"DELETE FROM `purchase_stock` WHERE purchase_id='$id'");
	if ($delete_qry) {
		
		echo "<script>alert('Deleted...')</script>";
        echo "<script>window.open('purchase_list.php','_self')</script>";
	}

?>