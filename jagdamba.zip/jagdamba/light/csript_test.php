<script >

alert('hello');
</script>